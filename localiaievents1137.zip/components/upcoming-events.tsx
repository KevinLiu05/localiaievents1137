"use client"

import { useEvents } from "@/lib/firebase-hooks"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import { Skeleton } from "@/components/ui/skeleton"
import { isAfter, isBefore, addDays } from "date-fns"

export function UpcomingEvents() {
  const { events, loading, error } = useEvents()

  // Filter to only show upcoming events (next 7 days)
  const today = new Date()
  const nextWeek = addDays(today, 7)

  const upcomingEvents = events
    .filter((event) => {
      if (!event.date) return false
      const eventDate = new Date(event.date)
      return isAfter(eventDate, today) && isBefore(eventDate, nextWeek)
    })
    .slice(0, 2)

  if (loading) {
    return (
      <section className="space-y-6">
        <div className="grid gap-4 md:grid-cols-2">
          {[...Array(2)].map((_, i) => (
            <Card key={i}>
              <CardHeader className="pb-3">
                <Skeleton className="h-6 w-3/4" />
              </CardHeader>
              <CardContent className="pb-3">
                <Skeleton className="h-4 w-full" />
                <Skeleton className="h-4 w-full" />
                <Skeleton className="h-4 w-2/3" />
              </CardContent>
              <div className="px-6 pb-6 pt-0">
                <Skeleton className="h-10 w-full" />
              </div>
            </Card>
          ))}
        </div>
      </section>
    )
  }

  if (error || upcomingEvents.length === 0) {
    return null // ✅ Removed "This Week at UW" header
  }

  return (
    <section className="space-y-6">
      <h2 className="text-2xl font-bold tracking-tight">Upcoming Events</h2>
      <div className="grid gap-4 md:grid-cols-2">
        {upcomingEvents.map((event) => (
          <Card key={event.id}>
            <CardHeader className="pb-3">
              <CardTitle className="text-lg">{event.title}</CardTitle>
              <div className="flex flex-wrap gap-1 mt-1">
                {event.tags?.map((tag) => (
                  <Badge key={tag} variant="outline">
                    {tag}
                  </Badge>
                ))}
              </div>
            </CardHeader>
            <CardContent className="pb-3">
              <p>{event.description || "No description available."}</p>
            </CardContent>
            <div className="px-6 pb-6 pt-0">
              <Button asChild className="w-full">
                <Link href={`/events/${event.id}`}>View Details</Link>
              </Button>
            </div>
          </Card>
        ))}
      </div>
    </section>
  )
}

